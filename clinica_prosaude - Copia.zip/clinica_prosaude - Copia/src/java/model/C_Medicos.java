package model;

public class C_Medicos {
	String nomemedico,
		   codigomedico,
		   codigoespecialidade,
		   crm;
		
	
	

	public C_Medicos() {
		super();
	}

	public C_Medicos(String nomemedico, String codigomedico, String codigoespecialidade, String crm) {
		super();
		this.nomemedico = nomemedico;
		this.codigomedico = codigomedico;
		this.codigoespecialidade = codigoespecialidade;
		this.crm = crm;
	}

	public String getNomemedico() {
		return nomemedico;
	}

	public void setNomemedico(String nomemedico) {
		this.nomemedico = nomemedico;
	}

	public String getCodigomedico() {
		return codigomedico;
	}

	public void setCodigomedico(String codigomedico) {
		this.codigomedico = codigomedico;
	}

	public String getCodigoespecialidade() {
		return codigoespecialidade;
	}

	public void setCodigoespecialidade(String codigoespecialidade) {
		this.codigoespecialidade = codigoespecialidade;
	}

	public String getCrm() {
		return crm;
	}

	public void setCrm(String crm) {
		this.crm = crm;
	}
	
}
